# practice-activities

This repo contains all practice activities from 1 to 15 week. You can just copy code and paste it into your files. 

P.S. week5.C is not complete, but it works