import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Ellipse;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.Scanner;

public class Circle extends Application {
    public static void main(String[] args) {
        Application.launch();
    }
    @Override
    public void start(Stage primaryStage) {
        Ellipse ellipse = new Ellipse(250, 250, 150, 100);
        Group root = new Group(ellipse);

        Scene scene = new Scene(root, 500, 500);

        primaryStage.setTitle("My App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
