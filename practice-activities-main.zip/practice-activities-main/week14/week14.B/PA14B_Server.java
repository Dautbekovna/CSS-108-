import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class PA14B_Server extends Application {
    @Override
    public void start(Stage primaryStage) {
        Label ServerLabel = new Label("Server: ");
        TextArea ServerTextArea = new TextArea();
        Label ClientLabel = new Label("Client: ");
        TextArea ClientTextArea = new TextArea();

        VBox vBox = new VBox();
        vBox.getChildren().addAll(ServerLabel, ServerTextArea, ClientLabel, ClientTextArea);

        Scene scene = new Scene(new ScrollPane(vBox), 500, 300);
        primaryStage.setTitle("PA14B_Server");
        primaryStage.setScene(scene);
        primaryStage.show();

        new Thread(() -> {
            try {
                ServerSocket serverSocket = new ServerSocket(8000);
                Socket socket = serverSocket.accept();

                DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
                DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());

                ServerTextArea.setOnKeyPressed(keyEvent -> {
                    if (keyEvent.getCode() == KeyCode.ENTER) {
                        try {
                            String sentence = ServerTextArea.getText();
                            outputToClient.writeUTF(sentence);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });

               while(true) {
                   String clientText = inputFromClient.readUTF();
                   Platform.runLater(() -> {
                       ClientTextArea.setText(clientText);
                   });
               }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }).start();
    }
}
