public interface Pet {
    public abstract String getName();
    public abstract void setName(String name);
    public abstract void play();
}
