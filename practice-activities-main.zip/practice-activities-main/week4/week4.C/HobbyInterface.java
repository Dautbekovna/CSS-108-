public interface HobbyInterface {
    public abstract String whatIsMyHobby();
    public abstract void setMyHobby(String hobby);
}
