public interface PersonInterface {
    public abstract void setName(String myName);
    public abstract void setAge(int myAge);
}
