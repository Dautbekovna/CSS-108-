public interface SportInterface {
    public abstract String getMyFavoriteSport();
    public abstract void setMyFavoriteSport(String sportName);
    public abstract int howMuchItCostToPlayThisSport();

}
