import java.lang.reflect.Field;

public class Person {
    private String name;
    private int age;
    private String address;
    private String phoneNumber;
    public Person(String name, int age, String address, String phoneNumber) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }

    protected Field[] getFields() {
        return this.getClass().getDeclaredFields();
    }

    @Override
    public String toString() {
        return this.getClass().getName() + " [name=" + this.name + ", age=" + this.age +
                ", address=" + this.address + ", phoneNumber=" + this.phoneNumber + "]";
    }
}
