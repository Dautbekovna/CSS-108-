public class Teacher extends Person {
    private String subject;
    public Teacher(String name, int age, String address, String phoneNumber, String subject) {
        super(name, age, address, phoneNumber);
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        String initialSentence = super.toString();
        return initialSentence.substring(0, initialSentence.length() - 2) +
                ", subject=" + this.subject + "]";
    }
}
