public class Student extends Person {
    private int studentID;
    private String major;
    public Student(String name, int age, String address, String phoneNumber, int studentID, String major) {
        super(name, age, address, phoneNumber);
        this.studentID = studentID;
        this.major = major;
    }

    public String getMajor() {
        return major;
    }
    public int getStudentID() {
        return studentID;
    }

    public void setMajor(String major) {
        this.major = major;
    }
    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    @Override
    public String toString() {
        String initialSentence = super.toString();
        return initialSentence.substring(0, initialSentence.length() - 2) +
                ", studentID=" + this.studentID + ", major=" + this.major + "]";
    }
}
